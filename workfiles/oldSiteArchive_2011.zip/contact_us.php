<?php 

require_once '/var/www/spcpress.com/httpdocs/library/HTMLPurifier.auto.php';
$purifier = new HTMLPurifier();

$page_title = "Contact Us";
function valid_email($email) {
  // First, we check that there's one @ symbol, and that the lengths are right
  if (!ereg("^[^@]{1,64}@[^@]{1,255}$", $email)) {
    // Email invalid because wrong number of characters in one section, or wrong number of @ symbols.
    return false;
  }
  // Split it into sections to make life easier
  $email_array = explode("@", $email);
  $local_array = explode(".", $email_array[0]);
  for ($i = 0; $i < sizeof($local_array); $i++) {
     if (!ereg("^(([A-Za-z0-9!#$%&#038;'*+/=?^_`{|}~-][A-Za-z0-9!#$%&#038;'*+/=?^_`{|}~\.-]{0,63})|(\"[^(\\|\")]{0,62}\"))$", $local_array[$i])) {
      return false;
    }
  }  
  return true;
} 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
	<title>SPC Press - <? echo "$page_title"; ?></title>
	<meta name="description" content="2 column fixed width layout.">
    <link href="screen.css" rel="stylesheet" type="text/css">
	<script type="text/javascript">
		function focus {
			document.contact_us.full_name.focus();
		}
	</script>
</head>
<body onload="focus();">

<div id="full_width_wrap">
	<div id="header">
	  <!--<h1>SPC Press, Inc.</h1>-->
	</div>
	<div id="nav">
		<? require("inc/mainnav.inc"); ?>
	</div>
	<div id="full_width_main">
		<h1><? echo "$page_title"; ?></h1>
		<!-- Begin form -->
		<? 
		if( (!($_POST['appt_formSent'])) || (!($_POST['full_name'])) || (!($_POST['email'])) || (!($_POST['phone_number'])) )
		{  ?>
	 		<p>Thank you for contacting SPC Press and Statistical Process Controls, Inc.  We value your feedback. </p>
			<? 
			//check for required fields
			if($_POST['appt_formSent']) {
				if(!($_POST['full_name'])) {
				echo("<span class='required_text'>Please fill in your name. </span>");
				} 
				if(!($_POST['email'])) {
					echo("<span class='required_text'>Please fill in your email. </span>");
				} 
				if(!($_POST['phone_number'])) {
				echo("<span class='required_text'>Please fill in your phone number. </span>");
				}
			}
			//end checking fields
			?>
			
		<form name="contact_us" action="contact_us.php" method="post">
		<input type="hidden" name="appt_formSent" value="true">
		<table width="700" border="0" cellpadding="4" cellspacing="0" class="contactform">
			<tr>
				<td width="200">Name</td>
				<td width="500"><input name="full_name" type="text" <? if ($_POST['full_name']) { ?> 
						value="<? echo($purifier->purify($_POST['full_name'])); ?>" <? } ?> />
				<span class="required">*</span></td>
			</tr>
			<tr>
				<td>Phone Number</td>
			<td><input type="text" name="phone_number" 
					<? if ($_POST['phone_number']) { ?> 
						value="<? echo($purifier->purify($_POST['phone_number'])); ?>"  <? } ?> />
				<span class="required">*</span></td>
			</tr>
			<tr>
				<td>Email Address</td>
				<td><input type="text" name="email" <? if ($_POST['email']) { ?> 
						value="<? echo($purifier->purify($_POST['email'])); ?>" <? } ?> />
				<span class="required">*</span></td>
			</tr>
			<tr>
				<td>Mailing Address</td>
				<td><input type="text" name="address" <? if ($_POST['address']) { ?> 
						value="<? echo($purifier->purify($_POST['address'])); ?>" <? } ?> />
				</td>
			</tr>
			<tr>
				<td>City</td>
				<td><input type="text" name="city" <? if ($_POST['city']) { ?> 
						value="<? echo($purifier->purify($_POST['city'])); ?>" <? } ?> />
				</td>
			</tr>
			<tr>
				<td>State</td>
				<td><input type="text" name="state"	<? if ($_POST['state']) { ?> 
						value="<? echo($purifier->purify($_POST['state'])); ?>" <? } ?> />
				</td>
			</tr>
			<tr>
				<td>Zip Code</td>
				<td><input type="text" name="zip"<? if ($_POST['zip']) { ?> 
						value="<? echo($purifier->purify($_POST['zip'])); ?>" 	<? } ?> />
				</td>
			</tr>
			<tr>
				<td>Comments</td>
				<td><textarea name="comments" cols="60" rows="5"><? if ($_POST['comments']) {  
						echo($purifier->purify($_POST['comments'])); } ?></textarea></td>
			</tr>
			<tr>
				<td colspan="2"><input type="submit" name="Submit" value="Submit" /></td>
			</tr>
		</table>
	</form>
<?  } else {

// initialize variables for To and Subject fields
################################################
# send-to address is $to                       #
################################################
$to = "spcservice@spcpress.com";
$from = $_POST['full_name'];
$phone = $_POST['phone_number'];
$email = $_POST['email'];
if($_POST['address']) { $address = $_POST['address'];  }
if($_POST['city']) {$city = $_POST['city']; }
if($_POST['state']) {$state = $_POST['state']; }
if($_POST['zip']) {$zip = $_POST['zip']; }
if($_POST['comments']) {$comments = $_POST['comments']; }
$subject = $from . ' has contacted you via spcpress.com.';

// build message body from variables received in the POST array

$message = $from . ' has sent you an appointment request.' . "\n\n";
$message .=  'Their phone number is ' . $phone . ".\n\n";
$message .=  'Their email address is ' . $email . ".\n\n";

if($address) {
	$message .= 'Address:  ' . $address . ".\n\n";
}
if($city) {
	$message .= 'City:  ' . $city . ".\n\n";
}
if($state) {
	$message .= 'State:  ' . $state . ".\n\n";
}
if($zip) {
	$message .= 'Zip:  ' . $zip . ".\n\n";
}
if($comments) {
	$message .= 'Comments:  ' . $comments . ".\n\n";
}

$message .= 'Sincerely,' . "\n\n" . 'Website Administrator';


// add additional email headers for more user-friendly reply
##################################################
$additionalHeaders = "From:" . $from . "<" . $email . ">\n";
$additionalHeaders .= "Reply-To: " . $email;

//check for vars
if($_POST['full_name']) {

	// send email message
	$OK = mail($to, $subject, $message, $additionalHeaders);
	// let Flash know what the result was
	if ($OK) {
	  echo "<h2>Thanks for your interest in our products and seminars.  Someone will contact you soon.</h2>";
	  }
	  else {
	  echo 'sent=failed&reason='. urlencode('There seems to be a problem with the server. Please try later.');
	  }
  
 }  else {
 	echo "This form was not submitted from an authorized SPC Press source.  ";
 
 }
} ?>
	
	</div>
	
	<div id="footer">
		<? require("inc/footer.inc"); ?>
	</div>
</div>
</body>
</html>
