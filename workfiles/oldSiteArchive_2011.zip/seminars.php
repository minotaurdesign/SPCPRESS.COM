<?php 
$page_title = "Seminars";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
	<title>SPC Press - <? echo "$page_title"; ?></title>
	<meta name="description" content="2 column fixed width layout.">
    <link href="screen.css" rel="stylesheet" type="text/css">
</head>
<body class="page_seminars">

<div id="wrap">
	<div id="header">
	  <!--<h1>SPC Press, Inc.</h1>-->
	</div>
	<div id="nav">
		<? require("inc/mainnav.inc"); ?>
	</div>
	<div id="main">
		<h1><? echo "$page_title"; ?></h1>
	<p><img src="images/big_djw.jpg" class="bigpic float_left" /></p><h2>Dr. Donald J. Wheeler</h2>
	<p><strong>Teaching SPC for 36 Years:</strong></p>
<p>Over 1000 Seminars held<br />
&nbsp;&nbsp;&nbsp;&nbsp;in 16 Countries<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; on 5 Continents;<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Author of 20
Books<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;and
150 Articles.</p>
<h2>Come learn from the Source!</h2>

		<dl>
			<dt><a href="seminars/sem_understanding_variation.php" title="Understanding Variation… An Executive Overview">Understanding Variation… An Executive Overview</a></dt>
			
			<dd>This powerful presentation is based upon the popular book, Understanding Variation …The Key to Managing Chaos. </dd>
			<dt><a href="seminars/sem_uspc.php" title="Understanding Statistical Process Control">Understanding
Statistical Process Control Seminar </a></dt>
			
			<dd>This is the basic 4-day seminar for people who work in manufacturing and process industries. </dd>
			<dt><a href="seminars/sem_making_sense_of_data.php" title="Making Sense of Data">Making
Sense of Data Seminar </a></dt>
			
			<dd>In this 4-day seminar you will learn tools and techniques which allow you to use business information and data in an effective, coherent program of Continual Improvement.</dd>
			<dt><a href="seminars/sem_practical_data_analysis.php" title="Practical Data Analysis… Doing Six Sigma Better">Practical
Data Analysis Seminar  </a></dt>
			
			<dd>This NEW four-day seminar is for engineers, technicians, and six sigma practitioners on every level. </dd>
			<dt><a href="seminars/sem_adv_topics_in_spc.php" title="Advanced Topics in Statistical Process Control">Advanced Topics in Statistical Process Control Seminar</a></dt>
			
			<dd>This 4-day seminar is intended for people who have a leadership role in the improvement process or those who will be teaching improvement techniques.</dd>
			<dt><a href="seminars/sem_successful_experimentation.php" title="Successful Experimentation">Successful
Experimentation Seminar </a></dt>
			
			<dd>This highly acclaimed 4-day seminar is built upon a unique approach to designed experiments. Rather than getting bogged down in mathematical theory, this course will help you develop a working knowledge of how to collect and analyze experimental data. </dd>
			<dt><a href="seminars/sem_from_capability_to_profitability.php" title="From Capability to Profitability">Capability
to Profitability Workshop</a></dt>
			
			<dd>This one-day workshop teaches how to maximize the profitability of your current processes by choosing the most cost-effective improvement strategies. </dd>
			<dt><a href="seminars/sem_eval_measurement_process.php" title="Evaluating the Measurement Process">Evaluating the Measurement Process Workshop</a></dt>
			
			<dd>In this 1-day workshop, you will learn how to improve your measurement process. Learn about the hazards of needless recalibration. Learn how to know when you must recalibrate. Go beyond the confusion of meaningless percentages and learn how to quantify how good your measurements actually are.</dd>
		</dl>
		<!--<h2>What others have said:</h2>
<blockquote>"Don Wheeler teaches profoundly important, practical ideas with great clarity and force, and without intellectual embroidery."</blockquote>
		<blockquote>"I can’t begin to describe the profound effect your presentation had on us!"</blockquote>
		<blockquote>"This seminar removed all the gobbledy-gook that I’d heard from others, leaving me with a clear set of tools that I can really apply to my job!"</blockquote>-->
	</div>
<div id="sidebar">
		<? require("inc/quick_contact.inc"); ?>
		<h1>Seminar Info</h1>
		<? require("inc/seminar_sidebar.inc"); ?>
	</div>
	<div id="footer">
		<? require("inc/footer.inc"); ?>
	</div>
</div>
</body>
</html>