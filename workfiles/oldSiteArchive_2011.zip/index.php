<?php 
$page_title = "Home";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
	<title>SPC Press - <? echo "$page_title"; ?></title>
	<meta name="description" content="2 column fixed width layout.">
    <link href="screen.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="wrap">
	<div id="header">
	  <!--<h1>SPC Press, Inc.</h1>-->
	</div>
	<div id="nav">
		<? require("inc/mainnav.inc"); ?>
	</div>
	<div id="main">
		<span class="biopic"><img src="images/djwheeler.jpg" alt="Donald J. Wheeler" /></span>
	  <div id="welcome">
			<h2>Welcome to the Web site of</h2>
			<h1>Dr. Donald J. Wheeler </h1>
</div>
		<p><strong>SPC Press</strong> offers you today’s best books on Statistical Process Control,
Six Sigma, Data Analysis, and Quality Improvement, including:</p>
		<ul>
			<li>Understanding Variation</li>
			<li>Understanding Statistical Process Control</li>
			<li>Evaluating the Measurement Process III</li>
			<li>Making Sense of Data</li>
			<li>The Six Sigma Practitioner’s Guide to Data Analysis</li>
			<li>Practical Process Improvement</li>
			<li>...and quality training tools.</li>
		</ul>

		<p><strong>Statistical Process Controls </strong>offers you today’s best training in Data Analysis Techniques, taught by the internationally recognized expert…Dr. Donald J. Wheeler.</p>
	</div>
	<div id="sidebar">
		<? require("inc/quick_contact_homepage.inc"); ?>
<!--		<h1>Latest SPC INKs</h1>
		<ul>
			<li><a href="#" title="March 2006 - SPC INK" target="">March 2006</a></li>
			<li><a href="#" title="May 2006 - SPC INK" target="">November 2006</a></li>
		</ul>
		<h1>Recent Articles by Donald J. Wheeler</h1>
		<ul>
			<li><a href="#" title="First Article" target="">How Should You Track Your
Quality Assurance Data?</a></li>
			<li><a href="#" title="Second Article" target=""></a></li>
		</ul>-->

		<p>&nbsp;</p> 
</div>
	<div id="footer">
		<? require("inc/footer.inc"); ?>
	</div>
</div>
</body>
</html>