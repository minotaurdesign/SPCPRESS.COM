<?php 
$page_title = "About Us";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
	<title>SPC Press - <? echo "$page_title"; ?></title>
	<meta name="description" content="2 column fixed width layout.">
    <link href="screen.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="wrap">
	<div id="header">
	  <!--<h1>SPC Press, Inc.</h1>-->
	</div>
	<div id="nav">
		<? require("inc/mainnav.inc"); ?>
	</div>
	<div id="main">
		<h1><? echo "$page_title"; ?></h1>
		<p>Welcome to Statistical Process Controls, Inc.…established by Dr. Donald J. Wheeler in 1982 to provide training and consulting for everyone who collects data and who needs to understand what it means so they can use it effectively!</p>
		<span class="float_right biopic"><img src="images/djwheeler.jpg" alt="Donald J. Wheeler" /></span>
		<p>For 30 years, Dr. Wheeler has been teaching people how to get the most out of their data. He graduated from the University of Texas with a Bachelor’s degree in Physics and Mathematics, and holds M.S. and Ph.D. Degrees in Statistics from Southern Methodist University. From 1970 to 1982 he taught in the Statistics Department at the University of Tennessee where he was an Associate Professor.</p>
		<p>Dr. Wheeler is a Fellow of both the American Statistical Association and the American Society for Quality. He has conducted over 1000 seminars in sixteen countries on five continents. He is author or co-author of 20 books and over 150 articles, as well as having been monthly columnist for both Quality Digest and Quality magazines. Through these seminars and books, and publications he has had a profound impact on companies and organizations around the world.</p>
		<span class="float_left"><img src="images/bookstack.jpg" alt="" /></span><p>In 1984, SPC Press was established with the aim of providing the very best books and training tools for those who work with data. Since then, we have published some of the leading authors in the field of data analysis and quality management, including the only authorized biography of W. Edwards Deming and the best book about Deming and his work: The Deming Dimension by Dr. Henry R. Neave. We’ve also published books by William Scherkenbach, Anita Simonton, Ron McCoy, Robert Wubbolding, Bryn Owen, Peter Malkovich, Leslie Kossoff, Lisa D. McNary, Ed Zunich, and Maury Cotter.</p>
		<span class="float_right"><img src="images/ink_banner.jpg" alt="SPC Ink" width="200" height="49" /></span>
<p>Our newsletter, SPC INK, has morphed from a very popular print piece to an
electronic mail out. This is published on a bi-monthly basis. To receive your
free subscription, <a href="mailto:spcservice@spcpress.com?subject=SPC INK">click
here: spcservice at spcpress.com.</a> Write SPC INK in the subject line.</p>
		<p>This newsletter keeps you up to date on the activities of our company and includes articles by many luminaries in the field of quality management and data analysis, including: Clare Crawford-Mason and Lloyd Dobyns, W. Edwards Deming, Dr. Al Phadt, Alfie Kohn, Dr. Lisa McNary, Dr. Henry R. Neave, Raymond Phillips, Dr. Paul Seldon, Dr. Peter Senge, Dr. Anita Simonton, Myron Tribus, Mary Walton, Dr. Robert Wubbolding, Ed Zunich…and of course, Dr. Donald J. Wheeler. These articles can still be read on the SPC INK Archive at our web site.</p>
		<h2>Talk to Us!</h2>
<p>Are you as tired as we are of listening to long advertisements and choosing from limitless, always-changing telephone menus? Call SPC during regular business hours and you will always talk to a live person. When our office is closed, you can leave a phone message and a person will call you the following business day. When you email us, you will receive a reply from a person, not a computer. So <a href="contact_us.php">send
us a note</a> or give us a call. We like hearing from you!</p>
	</div>
	<div id="sidebar">
		<? require("inc/quick_contact.inc"); ?>
	</div>
	<div id="footer">
		<? require("inc/footer.inc"); ?>
	</div>
</div>
</body>
</html>