<?php 
$page_title = "Other Products";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
	<title>SPC Press - <? echo "$page_title"; ?></title>
	<meta name="description" content="2 column fixed width layout.">
    <link href="screen.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="wrap">
	<div id="header">
	  <!--<h1>SPC Press, Inc.</h1>-->
	</div>
	<div id="nav">
		<? require("inc/mainnav.inc"); ?>
	</div>
	<div id="main">
		<h1>Welcome to SPC Press, Inc.</h1>
		<h2><? echo "$page_title"; ?></h2>
	
		<p>Our store is currently undergoing maintenance and renovation.  Please call us or email your merchandise order.  Thank you for your understanding.</p>
		

	</div>
	<div id="sidebar">
		<? require("inc/quick_contact.inc"); ?>
	</div>
	<div id="footer">
		<? require("inc/footer.inc"); ?>
	</div>
</div>
</body>
</html>