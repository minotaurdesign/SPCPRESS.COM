<?php 
$page_title = "Reading Room";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
	<title>SPC Press - <? echo "$page_title"; ?></title>
	<meta name="description" content="2 column fixed width layout.">
    <link href="screen.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="wrap">
	<div id="header">
	  <!--<h1>SPC Press, Inc.</h1>-->
	</div>
	<div id="nav">
		<? require("inc/mainnav.inc"); ?>
	</div>
	<div id="main">
		<h1><? echo "$page_title"; ?></h1>
		<p> Welcome to our Reading Room where you can find articles by Dr. Wheeler and other SPC Press Authors. You will need the Acrobat Reader to view the files. You can download the Reader <a href="http://www.adobe.com/products/acrobat/readstep2.html">here</a>. Click a link to open an article, or right-click and choose "Save As…" to save the document to your computer. </p>
		<h4>Articles by Donald J. Wheeler</h4>
       	<h5 class='reading'>Short Answers…</h5>
		<ul class="ink">
		<li><a href="pdf/DJW084.pdf">84. Two Plus Two Is Only Four On the Average</a></li>
        <li><a href="pdf/DJW157.pdf">157. Traffic Deaths Down for Third Straight Year</a></li>
        <li><a href="pdf/DJW124.pdf">124. Documenting the Savings</a></li>
        <li><a href="pdf/DJW192.pdf">192. Three Questions for Success</a></li>
        <li><a href="pdf/DJW111.pdf">111. Three Types of Action</a></li>
        <li><a href="pdf/DJW110.pdf">110. Five Ways to Use Shewhart's Charts</a></li>
        <li><a href="pdf/DJW129.pdf">129. A New Terminology</a></li>
        <li><a href="pdf/DJW175.pdf">175. Why Bother with Training in SPC?</a></li>
	  </ul>
        <h5>Longer Answers…</h5>
        <ul class="ink">
          <li><a href="pdf/DJW187.pdf">187. Shewhart, Deming, & Six Sigma</a></li>
          <li><a href="pdf/DJW088.pdf">88. Shewhart's Charts and the Probability Approach</a></li>
          <li><a href="pdf/DJW189.pdf">189. An Honest Gauge R&R Study</a></li>
          <li><a href="pdf/DJW177.pdf">177. The Six Sigma Zone</a></li>
          <li><a href="pdf/DJW173.pdf">173. Experiments, Randomization, & Observational Studies</a></li>
          <li><a href="pdf/two_ways_asq.pdf"> 209. Two Routes to Process Improvement</a></li>
        </ul>
      <h5>Sorry You Asked…</h5>
        <ul class="ink" >
          <li><a href="pdf/DJW165.pdf">165. Good Data, Bad Data, & Process Behavior Charts</a></li>
		  <li><a href="pdf/DJW168.pdf">168. How to Establish Manufacturing Specifications</a></li>
		  <li><a href="pdf/DJW191.pdf">191. What Happens After the Experiment?</a></li>
      </ul>
  <!-- PDF LIST -->
		<h4>Other Articles</h4>
 
	  <ul class="ink">
        <li><a href="pdf/only_reason_to_collect.pdf" title="Scherkenbach: The Only Reason to Collect Data">Scherkenbach: The Only Reason to Collect Data</a></li>
        <!--<li><a href="#"  title="Knowledge of Psychology">Knowledge of Psychology - Lisa McNary</a></li>-->
        <li><a href="pdf/Zunich.pdf"  title="Learning and Change">Zunich: Learning and Change</a></li>
	    <li><a href="pdf/deming_dimension.pdf"  title="Deming Dimension">Neave: The Deming Dimension</a> </li>
		<li><a href="pdf/deming_memorial_essay.pdf"  title="Deming Memorial Essay">McNary: Deming Memorial Essay </a></li>
		<li><a href="pdf/Selden.pdf"  title="Using SPC to Cure Sales Heartburn">Selden: Using SPC to Cure Sales Heartburn</a> </li>
        <li><a href="pdf/Senge.pdf"  title="Using SPC to Cure Sales Heartburn">Senge: The Leadership of Profound Change</a> </li>
        <li><a href="pdf/Simonton.pdf"  title="Using SPC to Cure Sales Heartburn">Simonton: The Leadership Balance</a> </li>
        <li><a href="pdf/Neave97.pdf"  title="Using SPC to Cure Sales Heartburn">Neave: A Study of SPC</a> </li>
	</ul>
    
		
  </div>
<div id="sidebar">
		<? require("inc/quick_contact.inc"); ?>
		<h1>SPC INK</h1>
		<ul><li><a href="ink/08_winter_newsletter.html">click here for current copy<br />
	    of our newsletter, SPC Ink</a></li>
		</ul>
  </div>
	<div id="footer">
		<? require("inc/footer.inc"); ?>
	</div>
</div>
</body>
</html>