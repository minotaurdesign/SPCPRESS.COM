<?php 
$page_title = "Seminars";
$seminar_title = "Capability to Profitability Workshop";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
	<title>SPC Press - <? echo "$page_title" . ": " . $seminar_title; ?></title>
	<meta name="description" content="2 column fixed width layout.">
    <link href="../screen.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="wrap">
	<div id="header"></div>
	<div id="nav">
		<? require("../inc/mainnav.inc"); ?>
	</div>
	<div id="main">
		<h2><? require "../inc/seminar_blurb.inc"; ?></h2>
		<h2><? echo "$seminar_title"; ?></h2>
		<p>This one-day workshop, available for in-house scheduling, teaches how to maximize the profitability of current processes by choosing the most cost-effective improvement strategies.  Using the Effective Cost of Production, you learn how to reduce excess costs, increase the profitability of operation, and document the dollars saved.</p>
		<p>It begins with a comprehensive treatment of the questions surrounding process capability.  Then, based on the average cost-of-use, capabilities are converted into Effective Costs of Production.  By evaluating the ECP for different scenarios you are able to determine potential savings from different improvement strategies.  This is the key to choosing the best improvement strategy.</p>
		<p>This workshop is intended for those dealing with capability issues in a production setting and those who are charged with improving processes and systems.  It should be an integral part of every Six Sigma initiative.		</p>
<h2>Topics in this workshop include:</h2>
<ul>
			<li>conformance versus lean production</li>
			<li>predicting the future for a process</li>
			<li>four possibilities for any process</li>
			<li>predictable and unpredictable processes</li>
			<li>capability for predictable processes</li>
			<li>converting capability indexes into fraction nonconforming</li>
			<li>capability for unpredictable processes</li>
			<li>performance indexes</li>
			<li>hypothetical capability for an unpredictable process</li>
			<li>capability ratios over time</li>
			<li>what capability indexes do and don't do</li>
			<li>capability for count data</li>
			<li>the costs of using conforming product</li>
			<li>the average cost-of-use concept</li>
			<li>the effective cost of production</li>
			<li>characterizing past performance</li>
			<li>the savings from operating on-target</li>
			<li>the saving from operating predictably</li>
			<li>the savings from operating both predictably and on-target</li>
			<li>the savings from process reengineering</li>
			<li>working with one-sided specifications</li>
			<li>working with targets at boundaries</li>
	</ul>
		<h2>This workshop uses the books:</h2>
<ul>
			<li>Reducing Production Costs</li>
	</ul>
	</div>
	<div id="sidebar">
		<? require("../inc/quick_contact.inc"); ?>
		<h1>Seminar Info</h1>
		<? require("../inc/seminar_sidebar.inc"); ?>
	</div>
	<div id="footer">
		<? require("../inc/footer.inc"); ?>
	</div>
</div>
</body>
</html>