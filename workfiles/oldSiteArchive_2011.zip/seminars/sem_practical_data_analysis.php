<?php 
$page_title = "Seminars";
$seminar_title = "Practical Data Analysis Seminar";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
	<title>SPC Press - <? echo "$page_title" . ": " . $seminar_title; ?></title>
	<meta name="description" content="2 column fixed width layout.">
    <link href="../screen.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="wrap">
	<div id="header"></div>
	<div id="nav">
		<? require("../inc/mainnav.inc"); ?>
	</div>
	<div id="main">
		<h2><? require "../inc/seminar_blurb.inc"; ?></h2>
		<h2><? echo "$seminar_title"; ?></h2>
		<p>Are you tired of the traditional classes in statistics?  Here is a seminar taught from the perspective of data analysis!</p>
		<p>This four-day seminar is for engineers, technicians, and six sigma practitioners on every level.  It provides a coherent, integrated approach to using the statistical techniques for data analysis in business and industry, combining the techniques covered in traditional engineering statistics courses with the process improvement techniques of SPC.  This seminar also incorporates the EMP workshop.</p>
		<p>The seminar also combines appropriate techniques with the specific situations you encounter in your day-to-day work. Within each situation, the techniques are arranged in order, beginning with the more general and easy-to-use tools and progressing to the more sophisticated and narrowly focused procedures.  This kind of organization provides each student with a range of appropriate techniques to use in each and every situation.</p>
		<p>The result of this unique organization is that complete mastery of each step is not required in order to make progress.  This makes the class suitable for both beginners and experienced users, with material that is useful for both groups.  Moreover, by emphasizing when and how to use the techniques, this course complements any statistical software package you may be using.  Nor does it require that you have any such software in order to perform meaningful and appropriate analyses.</p>
		<p>In addition to the survey of statistical techniques, you will also learn how to use the economic justification for taking action—the Effective Cost of Production.  By using this in a coherent, organized program of process improvement you can choose the right projects and the right improvement strategies.  When combined with the knowledge of which techniques to use, this approach to process improvement makes you highly effective in analyzing and using data.		</p>
<h2>Topics include:</h2>
<ul>
			<li>the difference between statistics and data analysis
			<li>what descriptive statistics do and their limitations
			<li>how to answer the fundamental question of data analysis
			<li>the difference between statistics and parameters
			<li>data collected under one, two, or three or more conditions
			<li>data collected at three or more values for X
			<li>count-based data
			<li>capability and performance indexes
			<li>using the Effective Cost of Production
			<li>the Six Sigma Zone
			<li>effective process improvement
			<li>how to do an honest Gauge R&R Study
	</ul>
		<p>You will leave this class with good reference books and the ability to use them effectively, including:</p>
		<ul>
			<li>The Six Sigma Practitioner's Guide to Data Analysis
			<li>The Process Evaluation Handbook
			<li>EMP III  Using Imperfect Data
		</ul>
	</div>
	<div id="sidebar">
		<? require("../inc/quick_contact.inc"); ?>
		<h1>Seminar Info</h1>
		<? require("../inc/seminar_sidebar.inc"); ?>
	</div>
	<div id="footer">
		<? require("../inc/footer.inc"); ?>
	</div>
</div>
</body>
</html>