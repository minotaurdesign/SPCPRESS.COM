<?php 
$page_title = "Seminars";
$seminar_title = "Evaluating the Measurement Process Workshop";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
	<title>SPC Press - <? echo "$page_title" . ": " . $seminar_title; ?></title>
	<meta name="description" content="2 column fixed width layout.">
    <link href="../screen.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="wrap">
	<div id="header"></div>
	<div id="nav">
		<? require("../inc/mainnav.inc"); ?>
	</div>
	<div id="main">
		<h2><? require "../inc/seminar_blurb.inc"; ?></h2>
		<h2><? echo "$seminar_title"; ?></h2>
		<p>This one-day workshop has been one of our most popular classes since the mid 1980s.  Now revised and based on the new book, EMP III, Using Imperfect Data, it is even better!  </p>
		<p>While most measurement system studies are set up to condemn measurement processes, this workshop shows you how to get the most from the measurement process that you have in place; how to get it to operate to its fullest potential.  Over the years, thousands of workshop participants have discovered the profound difference that comes from using the right approach to measurement system analysis.</p>
		<p>In this new workshop you will learn about the hazards of needless recalibration and how to know when recalibration is actually needed.  You will also learn how to use average and range charts to understand the measurement process, to characterize it, and to communicate this understanding to others.  Dr. Wheeler takes you far beyond the confusion of meaningless percentages and teaches you how to quantify how good your measurements actually are.</p>
		<p>This workshop is intended for technicians, engineers, and all those involved in collecting or using physical measurements of any kind.		</p>
<h2>Topics include:</h2>
<ul>
			<li>Using Process Behavior Charts for calibration, consistency and precision</li>
			<li>Assessing the consistency of a measurement system</li>
			<li>The effective resolution of a measurement</li>
			<li>The uses of the Probable Error</li>
			<li>Identifying and removing Operator Effects</li>
			<li>Identifying and removing Instrument Effects</li>
			<li>The usefulness of a measurement for characterizing a given product</li>
			<li>Characterizing the Relative Utility of a measurement</li>
			<li>What the Four Classes of Process Monitors mean in practice</li>
			<li>The problems with Gauge R&R studies </li>
			<li>How to perform an Honest Gauge R&R Study</li>
			<li>The effect of round-off on measurements</li>
			<li>Identifying and removing operator effects</li>
			<li>Identifying and removing instrument-to-instrument difference</li>
			<li>Comparing different measurement systems</li>
			<li>Round Robin studies</li>
	</ul>
		<p>While a one-day version of this workshop is incorporated into the Understanding SPC seminar and the Practical Data Analysis seminar, a two-day version of this workshop is available for in-house scheduling.  </p>
<p>In each case, the workshop uses EMP III Using Imperfect Data  as its textbook.</p>
</div>
	<div id="sidebar">
		<? require("../inc/quick_contact.inc"); ?>
		<h1>Seminar Info</h1>
		<? require("../inc/seminar_sidebar.inc"); ?>
	</div>
	<div id="footer">
		<? require("../inc/footer.inc"); ?>
	</div>
</div>
</body>
</html>