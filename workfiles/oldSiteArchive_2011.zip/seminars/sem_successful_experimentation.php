<?php 
$page_title = "Seminars";
$seminar_title = "Successful Experimentation Seminar";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
	<title>SPC Press - <? echo "$page_title" . ": " . $seminar_title; ?></title>
	<meta name="description" content="2 column fixed width layout.">
    <link href="../screen.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="wrap">
	<div id="header"></div>
	<div id="nav">
		<? require("../inc/mainnav.inc"); ?>
	</div>
	<div id="main">
		<h2><? require "../inc/seminar_blurb.inc"; ?></h2>
		<h2><? echo "$seminar_title"; ?></h2>
		<p>This highly acclaimed seminar is built upon a unique approach to designed experiments.  Rather than getting bogged down in mathematical theory, this course will help you develop a working knowledge of how to collect and analyze experimental data.  Throughout the course, the focus is on obtaining results that are understandable, usable, and capable of being clearly communicated to others.  To this end, the calculations are deliberately kept simple and comprehensible.</p>
		<p>This course is designed for engineers, technicians, scientists, and those who need to obtain and interpret experimental results.  The unique approach used in this seminar has proven to be suitable for both beginners and experts.</p>
		<p>For over 20 years, in company after company, this class has been identified as the beginning of a successful program of experimentation.  No matter how many other classes in designed experimentation you may have previously had, you will gain additional skills and knowledge from this one.</p>
		<p>If you are part of a Six Sigma program you cannot afford to miss this seminar.  Brown Belts, Black Belts, and Master Black Belts tell us they learn far more in this class than is included in traditional classes in experimental design.		</p>
<h2>Topics covered in this four-day course include:</h2>
<ul>
			<li>the analysis of means</li>
			<li>the one-way analysis of variance</li>
			<li>Tukey's post-hoc test</li>
			<li>using contrasts to make comparisons</li>
			<li>orthogonal sets of contrasts</li>
			<li>single degree-of-freedom analysis of variance</li>
			<li>multifactor analysis of variance</li>
			<li>analysis of variance for subgroups of size one</li>
			<li>scree plots and normal probability plots</li>
			<li>the analysis of messy data</li>
			<li>fractional factorial designs</li>
			<li>Plackett-Burman screening designs</li>
			<li>minimizing variation while getting on target</li>
			<li>Taguchi's approach to industrial experimentation</li>
	</ul>
		<p>This seminar is a structured workshop that uses exercises to constantly reinforce the concepts and techniques.  </p>
<h2>The books used include:</h2>
<ul>
			<li>Understanding Industrial Experimentation</li>
			<li>Tables of Screening Designs</li>
			<li>Range Based Analysis of Means</li>
	</ul>
	</div>
	<div id="sidebar">
		<? require("../inc/quick_contact.inc"); ?>
		<h1>Seminar Info</h1>
		<? require("../inc/seminar_sidebar.inc"); ?>
	</div>
	<div id="footer">
		<? require("../inc/footer.inc"); ?>
	</div>
</div>
</body>
</html>