<?php 
$page_title = "Seminars";
$seminar_title = "Making Sense of Data Seminar";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
	<title>SPC Press - <? echo "$page_title" . ": " . $seminar_title; ?></title>
	<meta name="description" content="2 column fixed width layout.">
    <link href="../screen.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="wrap">
	<div id="header"></div>
	<div id="nav">
		<? require("../inc/mainnav.inc"); ?>
	</div>
	<div id="main">
		<h2><? require "../inc/seminar_blurb.inc"; ?></h2>
		<h2><? echo "$seminar_title"; ?></h2>
		<p>This seminar is constructed around the three basic questions of improvement as a framework for Discovery through Data Analysis.  They are:</p>
		<ul>
			<li>What do you want to accomplish?</li>
			<li>By what method?</li>
			<li>How will you know?</li>
		</ul>
		<p>The answers to these three questions allow you to combine the various tools and techniques of data analysis into an effective and coherent approach—vital for any SPC, Six Sigma, or improvement effort of any name.</p>
		<p>Examples are drawn from all types of service and administrative areas, including healthcare, food service, accounting, banking, insurance, retail, distribution and sales, transportation, telemarketing, and telecommunications.  These examples illustrate how to utilize survey data, safety data, and all types of management data.</p>
		<p>While this is a basic seminar, it is also comprehensive.  It not only covers the material included in most introductory classes, but it also goes into the issues of effectively using these techniques.  Unlike many courses and books that present a bewildering array of different techniques, this course presents a unified approach that has a proven track record in all types of organizations.</p>
		<p>This seminar is intended for anyone who needs to learn how to use Data Analysis and SPC techniques in service or administrative areas.  The "Understanding Variation" workshop is also incorporated in this seminar.		</p>
		<h2>Topics include:</h2>
		<ul>
			<li>a framework for using data effectively</li>
			<li>flowcharts (process maps), block diagrams, and deployment flowcharts</li>
			<li>brainstorming</li>
			<li>cause-and-effect diagrams</li>
			<li>bar-charts, Pareto charts, histograms, and running records</li>
			<li>data collection</li>
			<li>using process behavior charts for data analysis</li>
			<li>charts for count data</li>
			<li>charts for trended data</li>
			<li>working with seasonal data</li>
			<li>using the tools interactively to achieve continual improvement</li>
		</ul>
			<h2>Books include the following:</h2>
			<ul>
				<li>Making Sense of Data</li>
				<li>Understanding Variation</li>
			</ul>
	</div>
	<div id="sidebar">
		<? require("../inc/quick_contact.inc"); ?>
		<h1>Seminar Info</h1>
		<? require("../inc/seminar_sidebar.inc"); ?>
	</div>
	<div id="footer">
		<? require("../inc/footer.inc"); ?>
	</div>
</div>
</body>
</html>