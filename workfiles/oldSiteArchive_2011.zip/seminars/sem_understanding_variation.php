<?php 
$page_title = "Seminars";
$seminar_title = "The Understanding Variation Workshop";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
	<title>SPC Press - <? echo "$page_title" . ": " . $seminar_title; ?></title>
	<meta name="description" content="2 column fixed width layout.">
    <link href="../screen.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="wrap">
	<div id="header"></div>
	<div id="nav">
		<? require("../inc/mainnav.inc"); ?>
	</div>
	<div id="main">
		<h2><? require "../inc/seminar_blurb.inc"; ?></h2>
		<h2><? echo "$seminar_title"; ?></h2>
		<p>This powerful presentation is based upon the popular book, Understanding Variation …The Key to Managing Chaos. Using typical management report data, the presentation shows you a better way to understand and use your own data. In company after company this workshop has been credited with being a turning point …the beginning of data-based management. This workshop is intended for executives and managers throughout the organization. For some it will be the starting point of further studies. For others it will become the catalyst that changes the way they make decisions and interpret data.</p>
		<h2>Topics in the four-hour version of this workshop include:</h2>
<ul>
			<li>the comparison of values and the problem of variation</li>
			<li>the principles for understanding data</li>
			<li>the specification approach to interpreting data</li>
			<li>the average value approach to interpreting data</li>
			<li>the process behavior chart approach</li>
			<li>the two mistakes of data analysis</li>
			<li>using data to gain insight into your processes</li>
			<li>comparisons between the approaches</li>
			<li>learning from your data</li>
			<li>the problem of fixing the wrong things</li>
			<li>a more effective way to understand your data</li>
	</ul>
		<p>An extended version of this workshop incorporates material from Avoiding Man-Made Chaos, extending the workshop to a full day. </p>
<h2>These additional topics typically include:</h2>
<ul>
			<li>The Germ Theory of Management</li>
			<li>constructing process behavior charts</li>
			<li>placing trended data on process behavior charts</li>
			<li>the right and wrong ways of computing limits</li>
	</ul>
		<h2>Participants Say:</h2>
		<blockquote>I can’t begin to describe the profound effect your workshop had on us! Everyone took back information that was immediately beneficial. We will never again be able to look at data in the same old way!</blockquote>
		<blockquote>"Don Wheeler teaches profoundly important, practical ideas with great clarity and force, and without intellectual embroidery."</blockquote>
		<blockquote>"I can’t begin to describe the profound effect your presentation had on us!"</blockquote>
		<blockquote>"This seminar removed all the gobbledy-gook that I’d heard from others, leaving me with a clear set of tools that I can really apply to my job!"</blockquote>

		<h2>Books include:</h2>
<ul>
			<li>Understanding Variation...The Key to Managing Chaos</li>
			<li>Avoiding Man-Made Chaos (full-day presentation only)</li>
	</ul>
		<p>This workshop is included in the Understanding SPC and Making Sense of Data Seminars. The workshop is not offered publicly as a stand-alone, but it can be scheduled for In-House presentation.</p>
	</div>
	<div id="sidebar">
		<? require("../inc/quick_contact.inc"); ?>
		<h1>Seminar Info</h1>
		<? require("../inc/seminar_sidebar.inc"); ?>
	</div>
	<div id="footer">
		<? require("../inc/footer.inc"); ?>
	</div>
</div>
</body>
</html>