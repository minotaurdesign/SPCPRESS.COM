<?php 
$page_title = "Seminars";
$seminar_title = "Advanced Topics in Statistical Process Control Seminar";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
	<title>SPC Press - <? echo "$page_title" . ": " . $seminar_title; ?></title>
	<meta name="description" content="2 column fixed width layout.">
    <link href="../screen.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="wrap">
	<div id="header"></div>
	<div id="nav">
		<? require("../inc/mainnav.inc"); ?>
	</div>
	<div id="main">
		<h2><? require "../inc/seminar_blurb.inc"; ?></h2>
		<h2><? echo "$seminar_title"; ?></h2>
		<p>In this seminar you will learn why the tools and techniques of SPC work the way they do.  This will free you from popular misconceptions and lay a sound foundation by providing clear explanations of the underlying theory.  As a result, you will learn how to use process behavior charts more effectively.</p>
		<p>The emphasis in this course is upon the "whys and wherefores" of SPC, rather than the "how-tos."  Those with a practical working knowledge of SPC or those with an extensive background in statistics will benefit most from this course.		</p>
<h2>Topics include:</h2>
<ul>
			<li>evaluating the measurement process</li>
			<li>degrees of freedom for process behavior charts</li>
			<li>different methods for estimating dispersion</li>
			<li>process behavior charts and chaos theory</li>
			<li>autocorrelated data and process behavior charts</li>
			<li>cumulative sum techniques</li>
			<li>the role of the central limit theorem</li>
			<li>precontrol and zone charts</li>
			<li>normality and the process behavior chart</li>
			<li>power functions for process behavior charts</li>
			<li>origins of scaling factors for process behavior charts</li>
			<li>21 different types of process behavior charts</li>
			<li>the theory behind charts for count data</li>
			<li>short run techniques</li>
			<li>difference charts and standardized charts </li>
			<li>differences between theory and practice</li>
			<li>using measurements to characterize product</li>
			<li>EWMA charts</li>
			<li>different detection rules</li>
	</ul>
		<p>You will leave this course with a comprehensive set of reference materials and the ability to use the effectively.  </p>
<h2>Books included are:</h2>
<ul>
			<li>Advanced Topics in Statistical Process Control</li>
			<li>EMP III Using Imperfect Data</li>
			<li>Normality and the Process Behavior Chart</li>
			<li>Short Run SPC</li>
	</ul>
	</div>
	<div id="sidebar">
		<? require("../inc/quick_contact.inc"); ?>
		<h1>Seminar Info</h1>
		<? require("../inc/seminar_sidebar.inc"); ?>
	</div>
	<div id="footer">
		<? require("../inc/footer.inc"); ?>
	</div>
</div>
</body>
</html>