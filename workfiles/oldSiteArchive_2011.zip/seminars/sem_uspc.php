<?php 
$page_title = "Seminars";
$seminar_title = "Understanding Statistical Process Control Seminar";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
	<title>SPC Press - <? echo "$page_title" . ": " . $seminar_title; ?></title>
	<meta name="description" content="2 column fixed width layout.">
    <link href="../screen.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="wrap">
	<div id="header"></div>
	<div id="nav">
		<? require("../inc/mainnav.inc"); ?>
	</div>
	<div id="main">
		<h2><? require "../inc/seminar_blurb.inc"; ?></h2>
		<h2><? echo "$seminar_title"; ?></h2>
		<p>This seminar is intended for all those who need to learn to use SPC and Data Analysis techniques in production, manufacturing, or process industries.  For those involved with a Six Sigma initiative, this course provides material that is essential for a successful program, but which is not included in most Six Sigma training.  The "Understanding Variation" workshop is also incorporated in this seminar.</p>
		<p>In this seminar you will learn how to discover the useful information in your data—one participant characterized it as "learning to listen to what your data is telling you"—and then use your discoveries in an effective, coherent program of Continual Improvement.</p>
		<p>While this is a basic seminar, it is also comprehensive.  It covers all the material included in most introductory classes, of course, but it also teaches you how to effectively use those techniques.  This course shows how others have used the techniques successfully, and it will provide you with a road map for your own success.</p>
		<h2>Topics include:</h2>
<ul>
		<li>four possibilities for any process</li>
		<li>different types of process behavior charts</li>
		<li>the uses of process behavior charts</li>
		<li>the logic behind the charts</li>
		<li>the origin of the scaling factors for the charts</li>
		<li>the empirical rule and the robustness of the charts</li>
		<li>right and wrong ways of computing limits</li>
		<li>myths and foundations concerning the charts</li>
		<li>rational sampling and rational subgrouping</li>
		<li>detection rules for the charts</li>
		<li>capability, predictability, and world-class quality</li>
		<li>turning capabilities into costs of production</li>
		<li>the problem of chunky data</li>
		<li>using count data effectively</li>
	</ul>
		<p>You will leave this class with a comprehensive set of reference materials and the ability to use them effectively.  
		
		<h2>Books include the following:</h2>
<ul>
		<li>Understanding Statistical Process Control, Third Edition</li>
		<li>Understanding Variation</li>
		<li>Reducing Production Costs</li>
		<li>EMP III, Using Imperfect Data</li>
	</ul>
	</div>
	<div id="sidebar">
		<? require("../inc/quick_contact.inc"); ?>
		<h1>Seminar Info</h1>
		<? require("../inc/seminar_sidebar.inc"); ?>
	</div>
	<div id="footer">
		<? require("../inc/footer.inc"); ?>
	</div>
</div>
</body>
</html>